@implementation MyClass 
	//Class methods defined here
@end
