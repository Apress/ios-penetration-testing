import UIKit

var str = 'Hello, Swift'
println(str)