@interface MyClass:NSObject{
	//Class Variable Here
}

//Class Properties here 
//Class methods and instances methods here

@end
