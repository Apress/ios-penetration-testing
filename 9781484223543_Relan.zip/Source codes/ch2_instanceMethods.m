- (int)addX:(int)x toY:(int)y {
	int sum = x + y;
	return sum;
	
}
int score = 20;
int updatedScore = [points addX:20 toY:score];
//the new score here is 40
